﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for adminlogin.xaml
	/// </summary>
	public partial class adminlogin : Window
	{
		public adminlogin()
		{
			InitializeComponent();
		}
		private void three_Click(object sender, RoutedEventArgs e)
		{
			new ShowTests().ShowDialog();
		}

		private void two_Click(object sender, RoutedEventArgs e)
		{
			new ShowTesters().ShowDialog();
		}

		private void one_Click(object sender, RoutedEventArgs e)
		{
			new ShowTrainees().ShowDialog();
		}

		private void four_Click(object sender, RoutedEventArgs e)
		{
			new TesterArea().ShowDialog();
		}
	}
}
