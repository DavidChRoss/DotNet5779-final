﻿using BE;
using BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for TesterArea.xaml
	/// </summary>
	public partial class TesterArea : Window
	{
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		BL.IBL bl;
		Tester tester;
		public TesterArea()
		{
			InitializeComponent();
			bl = BL.FactoryBL.getBL();
			tester = new Tester();
			this.thisGrid.DataContext = tester.Address;
			this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();

			// backgroundWorker1
			// 
			this.backgroundWorker1.WorkerReportsProgress = true;
			this.backgroundWorker1.WorkerSupportsCancellation = true;
			InitializeBackgroundWorker();
		}

		// Set up the BackgroundWorker object by 
		// attaching event handlers. 
		private void InitializeBackgroundWorker()
		{
			backgroundWorker1.DoWork +=
				new DoWorkEventHandler(backgroundWorker1_DoWork);
			backgroundWorker1.RunWorkerCompleted +=
				new RunWorkerCompletedEventHandler(
			backgroundWorker1_RunWorkerCompleted);
		}

		private void startAsyncButton_Click(System.Object sender,
			System.EventArgs e)
		{
			this.Panel.DataContext = null;

			this.startAsyncButton.IsEnabled = false;

			// Enable the Cancel button while 
			// the asynchronous operation runs.
			this.cancelAsyncButton.IsEnabled = true;

			// Start the asynchronous operation.
			backgroundWorker1.RunWorkerAsync(tester.Address);
		}

		private void cancelAsyncButton_Click(System.Object sender,
			System.EventArgs e)
		{
			// Cancel the asynchronous operation.
			this.backgroundWorker1.CancelAsync();

			// Disable the Cancel button.
			cancelAsyncButton.IsEnabled = false;
		}

		// This event handler is where the actual,
		// potentially time-consuming work is done.
		private void backgroundWorker1_DoWork(object sender,
			DoWorkEventArgs e)
		{
			// Get the BackgroundWorker that raised this event.
			BackgroundWorker worker = sender as BackgroundWorker;

			// Assign the result of the computation
			// to the Result property of the DoWorkEventArgs
			// object. This is will be available to the 
			// RunWorkerCompleted eventhandler.
			e.Result = ComputeDistance((string)e.Argument, worker, e);
		}

		// This event handler deals with the results of the
		// background operation.
		private void backgroundWorker1_RunWorkerCompleted(
			object sender, RunWorkerCompletedEventArgs e)
		{
			// First, handle the case where an exception was thrown.
			if (e.Error != null)
			{
				MessageBox.Show(e.Error.Message);
			}
			else if (e.Cancelled)
			{
				// Next, handle the case where the user canceled 
				// the operation.
				// Note that due to a race condition in 
				// the DoWork event handler, the Cancelled
				// flag may not have been set, even though
				// CancelAsync was called.
				this.Panel.DataContext= null;
			}
			else
			{
				// Finally, handle the case where the operation 
				// succeeded.
				this.Panel.DataContext = e.Result.ToString();
			}

			// Enable the Start button.
			startAsyncButton.IsEnabled = true;

			// Disable the Cancel button.
			cancelAsyncButton.IsEnabled = false;
		}

		// This is the method that does the actual work. For this
		// example, it computes a Fibonacci number and
		// reports progress as it does its work.
		IEnumerable<Tester> ComputeDistance(string n, BackgroundWorker worker, DoWorkEventArgs e)
		{
			IEnumerable<Tester> newList;
			newList = from item in bl.getAllTester()
					   where Distance.DistanceFromAddress(item, n) < item.MaxDistance
					   select item;

			// Abort the operation if the user has canceled.
			// Note that a call to CancelAsync may have set 
			// CancellationPending to true just after the
			// last invocation of this method exits, so this 
			// code will not have the opportunity to set the 
			// DoWorkEventArgs.Cancel flag to true. This means
			// that RunWorkerCompletedEventArgs.Cancelled will
			// not be set to true in your RunWorkerCompleted
			// event handler. This is a race condition.

			if (worker.CancellationPending)
			{
				e.Cancel = true;
			}
			return newList;		
		}
	}
}
