﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for ShowTesters.xaml
	/// </summary>
	public partial class ShowTesters : Window
	{
		IEnumerable<Tester> Testers;
		BL.IBL bl;
		public ShowTesters()
		{
			InitializeComponent();
			bl = BL.FactoryBL.getBL();
			Testers = from item in bl.getAllTester()
					   select item;
			DataContext = Testers;
		}
	}
}
