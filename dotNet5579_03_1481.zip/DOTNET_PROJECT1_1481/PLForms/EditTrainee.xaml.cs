﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for EditTrainee.xaml
	/// </summary>
	public partial class EditTrainee : Window
	{
		BE.Trainee trainee;
		BL.IBL bl;
		public EditTrainee()
		{
			InitializeComponent();
			trainee = new BE.Trainee();
			this.TraineeProperties.DataContext = trainee;
			bl = BL.FactoryBL.getBL();
			GenderComboBox.ItemsSource = Enum.GetValues(typeof(BE.Gender));
			VehicleTypeComboBox.ItemsSource = Enum.GetValues(typeof(BE.VehicleType));
			TransmissionTypeComboBox.ItemsSource = Enum.GetValues(typeof(BE.TransmissionType));
		}
		private void Add_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				bl.AddTrainee(trainee);
				MessageBox.Show("the trainee " + trainee.PrivateName + " " + trainee.FamilyName + " added  ", " Successfully updated! ");
				trainee = new BE.Trainee();
				this.DataContext = trainee;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void Update_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				bl.UpdateTrainee(trainee);
				MessageBox.Show("the trainee " + trainee.PrivateName + " " + trainee.FamilyName + " updated  ", " Successfully updated! ");
				trainee = new BE.Trainee();
				this.DataContext = trainee;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void Delete_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				BE.Trainee br = new BE.Trainee();
				br = bl.getAllTrainee().FirstOrDefault(b => b.NumTrainee == trainee.NumTrainee);
				if (br == null)
					throw new Exception("the trainee dosn't exist");
				else bl.deleteTrainee(br.NumTrainee);
				MessageBox.Show("the trainee \"" + br.PrivateName + " " + br.FamilyName + "\" Deleted from the system", "Deleted successfully!");
				this.DataContext = trainee;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
