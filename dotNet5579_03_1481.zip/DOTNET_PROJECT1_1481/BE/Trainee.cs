﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
	public class Trainee
	{
		public int NumTrainee { get; set; }
		public string FamilyName { get; set; }
		public string PrivateName { get; set; }
		public DateTime Birthday { get; set; }
		public Gender Gender { get; set; }
		public int PhoneNumber { get; set; }
		public string Address { get; set; }
		public TransmissionType TransmissionType { get; set; }
		public string SchoolName { get; set; }
		public VehicleType TypeOfVehicle { get; set; }
		public int NumTester { get; set; }
		public int NumLessons { get; set; }

		public override string ToString()//פונקצית הדפסה 
		{
			return "numTrainee: " + NumTrainee + "\nfamilyName: " + FamilyName + "\nprivateName" + PrivateName + "\nbirthday: " + Birthday + "\ngender: " + Gender + "\nphoneNumber: " + PhoneNumber + "\naddress : " + Address + "\nTransmissionType: " + TransmissionType + "\nschoolname : " + SchoolName + "\ntypeOfVehicle : " + TypeOfVehicle + "\ntheacherNumber : " + NumTester + "\nNumLessons : " + NumLessons;
		}
	}
}
