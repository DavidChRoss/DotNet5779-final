﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace BE
{
	public static class Configuration
	{
			public static int maxTeacherAge;
			public static int minLessons;
			public static int minTraineeAge;
			public static string testGap;

			public static string ToInt(List<bool> mylist)
			{
				var str = string.Join(",", mylist.Select(x => x ? "1" : "0"));
				return str;
			}
			public static List<bool> ToBool(string str)
			{
				List<bool> lst = new List<bool>();
				if (!string.IsNullOrWhiteSpace(str))
					lst = str.Split(',').Select(x => Convert.ToBoolean(int.Parse(x))).ToList();
				return lst;
			}
			public static DateTime GetNextWeekDay(DayOfWeek day)
			{
				DateTime result = DateTime.Now.AddDays(1);
				while (result.DayOfWeek != day)
					result = result.AddDays(1);
				return result;
			}
			public static Dictionary<DayOfWeek, List<bool>> ConvertToDictionary(XElement element)
			{
				Dictionary<DayOfWeek, List<bool>> dict = new Dictionary<DayOfWeek, List<bool>>();
				foreach (XElement el in element.Elements())
					dict.Add((DayOfWeek)Enum.Parse(typeof(DayOfWeek), el.Name.LocalName), ToBool(el.Value));
				return dict;
			}
		    public static XElement ToXElement<T>(this object obj)
		    {
			using (var memoryStream = new MemoryStream())
			{
				using (TextWriter streamWriter = new StreamWriter(memoryStream))
				{
					var xmlSerializer = new XmlSerializer(typeof(T));
					xmlSerializer.Serialize(streamWriter, obj);
					return XElement.Parse(Encoding.ASCII.GetString(memoryStream.ToArray()));
				}
			}
		}

		public static T FromXElement<T>(this XElement xElement)
		{
			var xmlSerializer = new XmlSerializer(typeof(T));
			return (T)xmlSerializer.Deserialize(xElement.CreateReader());
		}


	}
}
