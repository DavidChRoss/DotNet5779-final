﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
	public class Tester
	{
		public int NumTester { get; set; }
		public string FamilyName { get; set; }
		public string PrivateName { get; set; }
		public DateTime Birthday { get; set; }
		public Gender Gender { get; set; }
		public int PhoneNumber { get; set; }
		public string Address { get; set; }
		public int NumExperience { get; set; }
		public VehicleType VehicleType { get; set; }
		public double MaxDistance { get; set; }
		public int MaxTests { get; set; }
		public Dictionary<DayOfWeek, List<bool>> WorkTimes { get; set; }

		public override string ToString()//פונקצית הדפסה 
		{
			List<string> list = new List<string>(WorkTimes.Select(keyValuePair => keyValuePair.Key + "-" + Configuration.ToInt(keyValuePair.Value)));
			StringBuilder a = new StringBuilder();
			foreach (var parameter in list)
				a.AppendLine(parameter); ;
			return  "NumTester: " + NumTester + "\nfamilyName: " + FamilyName + "\nprivateName" + PrivateName + "\n birthday: " + Birthday + "\ngender: " + Gender + "\nphoneNumber: " + PhoneNumber + "\naddress : " + Address + "\nnumExperience : " + NumExperience + "\nmaxTests : " + MaxTests + "\nVehicleType : " + VehicleType + "\nmaxDistance : " + MaxDistance + "\nWorkTimes: " + a.ToString();
		}
	}
}

