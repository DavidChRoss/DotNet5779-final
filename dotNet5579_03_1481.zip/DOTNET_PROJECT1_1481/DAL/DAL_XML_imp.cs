﻿using BE;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Data;
using System.Xml;
using System.Xml.Serialization;

namespace DAL
{
	public class DAL_XML_imp : Idal
	{
		XElement TesterRoot;
		string TesterPath = @"TesterXml.xml";
		XElement TraineeRoot;
		string TraineePath = @"TraineeXml.xml";
		XElement TestRoot;
		string TestPath = @"TestXml.xml";
		XElement TestNumRoot;
		string TestNumPath = @"TestNumXml.xml";

		public DAL_XML_imp()
		{

			if (!File.Exists(TesterPath))
				CreateFileO();
			else
				LoadDataO();
			if (!File.Exists(TraineePath))
				CreateFileD();
			else
				LoadDataD();
			if (!File.Exists(TestPath))
				CreateFileB();
			else
				LoadDataB();
			if (!File.Exists(TestNumPath))
				TestNumCreateFile();
			else
				TestNumLoadData();

		}

		#region Tester Function

		private void CreateFileO()
		{
			TesterRoot = new XElement("Testers");
			TesterRoot.Save(TesterPath);
		}

		private void LoadDataO()
		{
			try
			{
				TesterRoot = XElement.Load(TesterPath);

			}
			catch
			{
				throw new Exception("File upload problem");
			}
		}
		public XElement ConvertTester(Tester o)
		{
			XElement TesterElement = new XElement("Tester");

			foreach (PropertyInfo item in typeof(Tester).GetProperties())
				if(item.Name != "WorkTimes")
					TesterElement.Add
					(
					new XElement(item.Name, item.GetValue(o, null))
					);
			TesterElement.Add(new XElement("WorkTimes", (from keyValue in o.WorkTimes
														 select new XElement((keyValue.Key).ToString(), Configuration.ToInt(keyValue.Value)))));
			return TesterElement;
		}
		public Tester ConvertTester(XElement element)
		{
			Tester o = new Tester();

			foreach (PropertyInfo item in typeof(Tester).GetProperties())
			{
				if (item.Name != "WorkTimes")
				{
					TypeConverter typeConverter = TypeDescriptor.GetConverter(item.PropertyType);
					object convertValue = typeConverter.ConvertFromString(element.Element(item.Name).Value);
					item.SetValue(o, convertValue);
				}
			}
			o.WorkTimes = Configuration.ConvertToDictionary(element.Element("WorkTimes"));
			return o;
		}

		public bool findTester(Tester O)
		{
			XElement TesterElement;
			TesterElement = (from p in TesterRoot.Elements()
							 where Convert.ToInt32(p.Element("NumTester").Value) == O.NumTester
							 select p).FirstOrDefault();
			if (TesterElement == null)
				return false;
			return true;
		}

		public void AddTester(Tester o)
		{
			if (findTester(o))
				throw new Exception("!שם זה כבר קיים במערכת");
			TesterRoot.Add(ConvertTester(o));
			TesterRoot.Save(TesterPath);
		}

		public void deleteTester(int num)
		{
			XElement TesterElement;
			TesterElement = (from p in TesterRoot.Elements()
							 where Convert.ToInt32(p.Element("NumTester").Value) == num
							 select p).FirstOrDefault();
			if (TesterElement == null)
				throw new Exception(" שאתה מנסה למחוק אינה קיימת Tester");
			TesterElement.Remove();
			TesterRoot.Save(TesterPath);
		}

		public void UpdateTester(Tester o)
		{
			XElement TesterElement = (from p in TesterRoot.Elements()
									   where Convert.ToInt32(p.Element("NumTester").Value) == o.NumTester
									   select p).FirstOrDefault();
			if (TesterElement == null)
				throw new Exception("Tester with the same number not found...");
			TesterElement.Remove();
			TesterRoot.Add(ConvertTester(o));
			TesterRoot.Save(TesterPath);
		}
		public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)
		{
			if (predicat == null)
			{
				return from item in TesterRoot.Elements()
					   select ConvertTester(item);
			}
			return from item in TesterRoot.Elements()
				   let s = ConvertTester(item)
				   where predicat(s)
				   select s;
		}

		public List<Tester> TesterList()
		{
			List<Tester> Testers = new List<Tester>();
			try
			{
				Testers = (from item in TesterRoot.Elements()
						  select new Tester()
						  {
							  NumTester = Convert.ToInt32(item.Element("NumTester").Value),
							  PhoneNumber = Convert.ToInt32(item.Element("PhoneNumber").Value),
							  FamilyName = Convert.ToString(item.Element("FamilyName").Value),
							  Address = Convert.ToString(item.Element("Address").Value),
							  PrivateName = Convert.ToString(item.Element("PrivateName").Value),
							  MaxTests = Convert.ToInt32(item.Element("MaxTests").Value),
							  NumExperience = Convert.ToInt32(item.Element("NumExperience").Value),
							  Gender = (Gender)Enum.Parse(typeof(Gender), item.Element("Gender").Value),
							  VehicleType = (VehicleType)Enum.Parse(typeof(VehicleType), item.Element("VehicleType").Value),
							  Birthday = Convert.ToDateTime(item.Element("Birthday").Value),
							  MaxDistance = Convert.ToDouble(item.Element("MaxDistance").Value),
							  WorkTimes = Configuration.ConvertToDictionary(item.Element("WorkTimes")),

						  }).ToList();
			}
			catch
			{
				Testers = null;
			}
			return Testers;
		}
		#endregion

		#region Trainee Function

		private void CreateFileD()
		{
			TraineeRoot = new XElement("Trainees");
			TraineeRoot.Save(TraineePath);
		}
		private void LoadDataD()
		{
			try
			{
				TraineeRoot = XElement.Load(TraineePath);

			}
			catch
			{
				throw new Exception("File upload problem");
			}
		}
		public XElement ConvertTrainee(Trainee d)
		{
			var doc = new XDocument();
			using (XmlWriter writer = doc.CreateWriter())
			{
				XmlSerializer serializer = new XmlSerializer(d.GetType());
				serializer.Serialize(writer, d);
			}

			return doc.Root;
		}
		public Trainee ConvertTrainee(XElement element)
		{
			using (XmlReader reader = element.CreateReader())
			{
				XmlSerializer serializer = new XmlSerializer(typeof(Trainee));
				Trainee typed = (Trainee)serializer.Deserialize(reader);
				return typed;
			}
		}

		public bool findTrainee(Trainee D)
		{
			XElement TraineeElement;
			TraineeElement = (from p in TraineeRoot.Elements()
							 where Convert.ToInt32(p.Element("NumTrainee").Value) == D.NumTrainee
							 select p).FirstOrDefault();
			if (TraineeElement == null)
				return false;
			return true;
		}

		public void AddTrainee(Trainee d)
		{
			if (findTrainee(d))
				throw new Exception("!שם זה כבר קיים במערכת");
			TraineeRoot.Add(ConvertTrainee(d));
			TraineeRoot.Save(TraineePath);

		}

		public void deleteTrainee(int num)
		{
			XElement TraineeElement;
			TraineeElement = (from p in TraineeRoot.Elements()
							  where Convert.ToInt32(p.Element("NumTrainee").Value) == num
							  select p).FirstOrDefault();
			if (TraineeElement == null)
				throw new Exception("You are trying to delete a Trainee that does not exist");
			TraineeElement.Remove();
			TraineeRoot.Save(TraineePath);
		}

		public void UpdateTrainee(Trainee d)
		{
			XElement TraineeElement = (from p in TraineeRoot.Elements()
									   where Convert.ToInt32(p.Element("NumTrainee").Value) == d.NumTrainee
									   select p).FirstOrDefault();
			if (TraineeElement == null)
				throw new Exception("Trainee with the same number not found...");
			TraineeElement.Remove();
			TraineeRoot.Add(ConvertTrainee(d));
			TraineeRoot.Save(TraineePath);

		}

		public IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null)
		{
			IEnumerable<Trainee> Trainees;
			if (predicat == null)
			{
				Trainees = (from item in TraineeRoot.Elements()
							select ConvertTrainee(item));
			}
			else
			{
				Trainees = (from item in TraineeRoot.Elements()
					        let s = ConvertTrainee(item)
					        where predicat(s)
					        select s);
			}
			return Trainees;
		}

		public List<Trainee> TraineeList()
		{
			List<Trainee> Trainees = new List<Trainee>();
			try
			{
				Trainees = (from item in TraineeRoot.Elements()
							select new Trainee()
							{
								NumTrainee = Convert.ToInt32(item.Element("NumTrainee").Value),
								PrivateName = Convert.ToString(item.Element("PrivateName").Value),
								FamilyName = Convert.ToString(item.Element("FamilyName").Value),
								Address = Convert.ToString(item.Element("Address").Value),
								NumLessons = Convert.ToInt32(item.Element("NumLessons").Value),
								PhoneNumber = Convert.ToInt32(item.Element("PhoneNumber").Value),
								Gender = (Gender)Enum.Parse(typeof(Gender), item.Element("Gender").Value),
								Birthday = Convert.ToDateTime(item.Element("Birthday").Value),
								TransmissionType = (TransmissionType)Enum.Parse(typeof(TransmissionType), item.Element("TransmissionType").Value),
								SchoolName = Convert.ToString(item.Element("SchoolName").Value),
								NumTester = Convert.ToInt32(item.Element("NumTester").Value),
								TypeOfVehicle = (VehicleType)Enum.Parse(typeof(VehicleType), item.Element("TypeOfVehicle").Value),

							}).ToList();
			}
			catch
			{
				Trainees = null;
			}
			return Trainees;

		}

		#endregion

		#region Test Function

		private void CreateFileB()
		{
			TestRoot = new XElement("Tests");
			TestRoot.Save(TestPath);
		}
		private void LoadDataB()
		{
			try
			{
				TestRoot = XElement.Load(TestPath);

			}
			catch
			{
				throw new Exception("File upload problem");
			}
		}
		private void TestNumCreateFile()
		{
			TestNumRoot = new XElement("TestIDs");
			TestNumRoot.Add(new XElement("numStatic", 1000));
			TestNumRoot.Save(TestNumPath);
		}
		private void TestNumLoadData()
		{
			try
			{
				TestNumRoot = XElement.Load(TestNumPath);

			}
			catch
			{
				throw new Exception("File upload problem");
			}
		}
		public XElement ConvertTest(Test b)
		{
			var doc = new XDocument();
			var xmlSerializer = new XmlSerializer(typeof(Test));
			using (var writer = doc.CreateWriter())
			{
				xmlSerializer.Serialize(writer, b);
			}

			return doc.Root;
		}
		public Test ConvertTest(XElement element)
		{
			using (XmlReader reader = element.CreateReader())
			{
				XmlSerializer serializer = new XmlSerializer(typeof(Test));
				Test typed = (Test)serializer.Deserialize(reader);
				return typed;
			}
		}

		public bool findTest(Test B)
		{
			XElement TestElement;
			TestElement = (from p in TestRoot.Elements()
							 where Convert.ToInt32(p.Element("TestID").Value) == B.TestID
							 select p).FirstOrDefault();
			if (TestElement == null)
				return false;
			return true;
		}

		public void AddTest(Test b)
		{
			b.TestDate = b.SetUpDate;
			int num = int.Parse(TestNumRoot.Element("numStatic").Value);
			b.TestID = num;
			TestNumRoot.Element("numStatic").Value = ++num + "";
			if (findTest(b) == true)
				throw new Exception("!שם זה כבר קיים במערכת");

			XElement TestID = new XElement("TestID", b.TestID);
			XElement NumTester = new XElement("NumTester", b.NumTester);
			XElement TestDate = new XElement("TestDate", b.TestDate);
			XElement NumTrainee  = new XElement("NumTrainee", b.NumTrainee);
			XElement TestType = new XElement("TestType", b.TestType);
			XElement TestAddress = new XElement("TestAddress", b.TestAddress);
			XElement SetUpDate = new XElement("SetUpDate", b.SetUpDate);

			TestRoot.Add(new XElement("Test", TestID, NumTester, NumTrainee, SetUpDate, TestDate, TestAddress, TestType));			
			TestNumRoot.Save(TestNumPath);
			TestRoot.Save(TestPath);

		}
		public void deleteTest(int num)
		{
			XElement TestElement;
			TestElement = (from p in TestRoot.Elements()
						   where Convert.ToInt32(p.Element("TestID").Value) == num
						   select p).FirstOrDefault();
			if (TestElement == null)
				throw new Exception("You are trying to delete a Test that does not exist");
			TestElement.Remove();
			TestRoot.Save(TestPath);

		}

		public void UpdateTest(Test b)
		{

			TestRoot = XElement.Load(TestPath);
			XElement item = (from p in TestRoot.Elements()
									where Convert.ToInt32(p.Element("TestID").Value) == b.TestID
									select p).FirstOrDefault();
			if (item == null)
				throw new Exception("Test with the same number not found...");

			XElement DistanceParameter = new XElement("DistanceParameters", b.DistanceParameters);
			XElement ParkingParameter = new XElement("ParkingParameters", b.ParkingParameters);
			XElement AwarenessParameter = new XElement("AwarenessParameters", b.AwarenessParameters);
			XElement LightsParameter = new XElement("LightsParameters", b.LightsParameters);
			XElement Comments = new XElement("Comments", b.Comments);
			XElement TestGrade = new XElement("TestGrade", b.TestGrade);
			item.Add(TestGrade, Comments, DistanceParameter, ParkingParameter, AwarenessParameter, LightsParameter);
			
			TestRoot.Save(TestPath);
		}

		public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
		{
			IEnumerable<Test> Tests;
			try
			{
				Tests = (from item in TestRoot.Elements()
						 select new Test()
						 {
							 TestID = Convert.ToInt32(item.Element("TestID").Value),
							 DistanceParameters = (DistanceParameters)Enum.Parse(typeof(DistanceParameters), item.Element("DistanceParameters").Value),
							 AwarenessParameters = (AwarenessParameters)Enum.Parse(typeof(AwarenessParameters), item.Element("AwarenessParameters").Value),
							 ParkingParameters = (ParkingParameters)Enum.Parse(typeof(ParkingParameters), item.Element("ParkingParameters").Value),
							 LightsParameters = (LightsParameters)Enum.Parse(typeof(LightsParameters), item.Element("LightsParameters").Value),
							 NumTester = Convert.ToInt32(item.Element("NumTester").Value),
							 NumTrainee = Convert.ToInt32(item.Element("NumTrainee").Value),
							 TestType = (VehicleType)Enum.Parse(typeof(VehicleType), item.Element("TestType").Value),
							 TestDate = DateTime.Parse(item.Element("TestDate").Value),
							 SetUpDate = DateTime.Parse(item.Element("SetUpDate").Value),
							 TestAddress = Convert.ToString(item.Element("TestAddress").Value),
							 TestGrade = (Grade)Enum.Parse(typeof(Grade), item.Element("TestGrade").Value),
							 Comments = Convert.ToString(item.Element("Comments").Value),
						 }).ToList();
				if (predicat != null)
				{
					Tests = Tests.Where(predicat);
				}
			}
			catch
			{
				Tests = null;
			}
			if (predicat == null)
			{
				Tests = (from item in TestRoot.Elements()
							select ConvertTest(item));
			}
			else
			{
				Tests = (from item in TestRoot.Elements()
							let s = ConvertTest(item)
							where predicat(s)
							select s);
			}
			return Tests;
		}

		public List<Test> TestList()
		{

			TestRoot = XElement.Load(TestPath);
			Test T = new Test();
			T.TestID = 0;
			List<Test> Tests = new List<Test>();
			try
			{ 
				Tests = (from item in TestRoot.Elements()
						 select new Test()
						 {
							 TestID = Convert.ToInt32(item.Element("TestID").Value),
							 DistanceParameters = (DistanceParameters)Enum.Parse(typeof(DistanceParameters), item.Element("DistanceParameters").Value),
							 AwarenessParameters = (AwarenessParameters)Enum.Parse(typeof(AwarenessParameters), item.Element("AwarenessParameters").Value),
							 ParkingParameters = (ParkingParameters)Enum.Parse(typeof(ParkingParameters), item.Element("ParkingParameters").Value),
							 LightsParameters = (LightsParameters)Enum.Parse(typeof(LightsParameters), item.Element("LightsParameters").Value),
							 NumTester = Convert.ToInt32(item.Element("NumTester").Value),
							 NumTrainee = Convert.ToInt32(item.Element("NumTrainee").Value),
							 TestType = (VehicleType)Enum.Parse(typeof(VehicleType), item.Element("TestType").Value),
							 TestDate = DateTime.Parse(item.Element("TestDate").Value),
							 SetUpDate = DateTime.Parse(item.Element("SetUpDate").Value),
							 TestAddress = Convert.ToString(item.Element("TestAddress").Value),
							 TestGrade = (Grade)Enum.Parse(typeof(Grade), item.Element("TestGrade").Value),
							 Comments = Convert.ToString(item.Element("Comments").Value),
						 }).ToList();
			}
			catch
		    {
				Tests.Add(T);
			}
			return Tests;
		}
		#endregion
	}
}
