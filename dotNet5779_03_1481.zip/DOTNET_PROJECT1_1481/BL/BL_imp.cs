﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DAL;
using DS;
using System.Collections;

namespace BL
{
	public class BL_imp : IBL
	{
		DAL.Idal dal = DAL.FactoryDalXml.getdal();
		/// <summary>
		/// does not allow tester under 40
		/// </summary>
		/// <param name="num"></param>
		/// <returns></returns>
		public void TesterAge(int num)
		{
			if (num < 40)
				throw new Exception("you are too young, to the gas chambers for you");
		}

		/// <summary>
		/// does not allow trainee under 18
		/// </summary>
		/// <param name="num"></param>
		/// <returns></returns>
		public void TraineeAge(int num)
		{
			if (num < 18)
				throw new Exception("you are too young, to the gas chambers for you");
		}

		/// <summary>
		/// does not allow trainee to add test before a week has pasted since his previous one
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TestGap(Test b)
		{
			Trainee t = dal.getAllTrainee(a => b.NumTrainee == a.NumTrainee).FirstOrDefault();
			if (t == null)
				throw new Exception("Trainee does not exist");
			if (dal.getAllTest() != null)
			{
				foreach (Test T in dal.getAllTest())
				{
					if (T.NumTrainee == t.NumTrainee)
						if (Math.Abs((b.SetUpDate - T.SetUpDate).TotalDays) < 7)
							throw new Exception("The tests are too close together");
				}
			}
		}

		/// <summary>
		/// does not allow trainee to add test before he has done 20 lessons
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckLessons(Test b)
		{
			Trainee t = dal.getAllTrainee(a => b.NumTrainee == a.NumTrainee).FirstOrDefault();
			if (t == null)
				throw new Exception("Trainee does not exist");
			if (t.NumLessons < 20)
				throw new Exception("You have not done enough lessons");
		}

		/// <summary>
		/// does not allow trainee to add test if there  tester is unavailable that day
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void Availability(Test b)
		{
			Tester t = dal.getAllTester(c => b.NumTester == c.NumTester).FirstOrDefault();
			if (t == null)
				throw new Exception("tester does not exist");
			if (b.SetUpDate.DayOfWeek > DayOfWeek.Thursday || b.SetUpDate.DayOfWeek < DayOfWeek.Sunday)
				throw new Exception("The Tester is unavailable on the weekend");
			if (!String.Concat(Configuration.ToInt(t.WorkTimes[b.SetUpDate.DayOfWeek]).Split(',')).Contains('1'))
			      throw new Exception("The Date is unavailable");
		}

		/// <summary>
		/// does not allow tester to be added to test if he has surpassed his weekly test limit
		/// </summary>
		/// <param name="b"></param>
		/// <param name="d"></param>
		/// <returns></returns>
		public void TesterMax(Test b)
		{
			Tester t = dal.getAllTester(c => b.NumTester == c.NumTester).FirstOrDefault();
			if (t == null)
				throw new Exception("tester does not exist");
			int num = 0;
			if (dal.getAllTest() != null)
			{
				foreach (Test T in dal.getAllTest())
				{
					if (T.NumTester == b.NumTester)
						if (T.SetUpDate.DayOfYear - b.SetUpDate.DayOfYear < 7 && T.SetUpDate.DayOfYear - b.SetUpDate.DayOfYear > -7)
							num++;
				}
			}
			if (num > t.MaxTests)
				throw new Exception("You have done too many tests");
		}

		/// <summary>
		/// does not allow test to be modified if it is missing fields
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckFields(Test b)
		{
			var properties = b.GetType().GetProperties(System.Reflection.BindingFlags.Public);
			foreach (var prop in properties)
			{
				if (!prop.CanRead)
					continue;
				else if (prop.PropertyType.IsValueType)
					continue;
				Object value = prop.GetValue(prop.GetGetMethod().IsStatic ? null : b);
				if (Object.ReferenceEquals(null, value))
					throw new Exception("not all fields have been filled in");
				String str = value as String;
				if (null != str)
					if (str.Equals(""))
						throw new Exception("not all fields have been filled in");
			}
		}

		/// <summary>
		/// does not allow test to be added if tester or trainee already has test at the same time
		/// </summary>
		/// <param name="b"></param>
		/// <returns></returns>
		public void TestTime(Test b)
		{
			if (dal.getAllTest() != null)
			{
				foreach (Test T in dal.getAllTest())
				{
					if (T.NumTester == b.NumTester || T.NumTrainee == b.NumTrainee)
						if (b.SetUpDate == T.SetUpDate)
							throw new Exception("there is already a test at that time");
				}
			}
		}
		/// <summary>
		/// does not allow test to be added if trainee has already passed test on that vehicle type
		/// </summary>
		/// <param name="d"></param>
		/// <param name="b"></param>
		/// <returns></returns>
		public void CheckVehicle(Test b)
		{
			if (dal.getAllTest() != null)
			{
				foreach (Test T in dal.getAllTest())
				{
					if (T.NumTrainee == b.NumTrainee)
						if (T.TestType == b.TestType && T.TestGrade == Grade.pass)
							throw new Exception("trainee has already passed test on that vehicle type");
				}
			}
		}

		/// <summary>
		/// ensures that the vehicle type that the trainee learned to drive is the same as the testers vehicle
		/// </summary>
		/// <param name="o"></param>
		/// <param name="d"></param>
		/// <returns></returns>
		public void SetTest(Test b)
		{
			Trainee t = dal.getAllTrainee(a => b.NumTrainee == a.NumTrainee).FirstOrDefault();
			Tester s = dal.getAllTester(c =>  b.NumTester == c.NumTester).FirstOrDefault();
			if (t ==null || s == null)
				throw new Exception("Trainee or tester does not exist");
			if (s.VehicleType != t.TypeOfVehicle)
				throw new Exception("Vehicle types are different");
			    
		}

		/// <summary>
		/// returns list of all testers within certain distance of the given address
		/// </summary>
		/// <param name="address"></param>
		/// <returns></returns>
		public List<Tester> TesterArea(string address)
		{
			var list = from item in getAllTester()
					   where Distance.DistanceFromAddress(item, address) < item.MaxDistance
					   select item;
			List<Tester> newList = new List<Tester>();
			foreach (var s in list)
				newList.Add(s);
			return newList;

		}

		// <summary>
		/// returns list of all testers who are free at the given time 
		/// </summary>
		/// <param name="time"></param>
		/// <returns></returns>
		public List<Tester> TesterTime(DateTime time)
		{
			List<Tester> newList = new List<Tester>();
			foreach (Tester item in TesterList())
			{
				foreach (Test T in dal.getAllTest())
				{
					if (item.NumTester == T.NumTester)
						if(T.SetUpDate == time)
							newList.Add(item);
				}
			}
			var result = TesterList().Except(newList);
			return result.ToList();
		}

		// <summary>
		/// returns list of tests organized according to certain condition
		/// </summary>
		/// <param name="condition"></param>
		/// <returns></returns>
		public List<Test> Condition_Tests(conditionDelegate condition)
		{
			var list = from item in TestList()
					   where condition(item)
					   select item;
			List<Test> newList = new List<Test>();
			foreach (var s in list)
				newList.Add(s);
			return newList;

		}

		// <summary>
		/// returns number of tests a trainee has done
		/// </summary>
		/// <param name="d></param>
		/// <returns></returns>
		public int NumTraineeTests(Trainee d)
		{
			int num = 0;
			if (TestList().Any())
			{
				foreach (Test T in TestList())
				{
					if (d.NumTrainee == T.NumTrainee)
						num++;
				}
			}
			return num;
		}

		// <summary>
		/// checks if trianee has passed any tests
		/// </summary>
		/// <param name="d></param>
		/// <returns></returns>
		public bool PassedTest(Trainee d)
		{
			bool flag = false;
			if (TestList().Any())
			{
				foreach (Test T in TestList())
				{
					if (d.NumTester == T.NumTester)
						if (T.TestGrade == Grade.pass)
							flag = true;
				}
			}
			return flag;
		}

		// <summary>
		/// returns all tests planned for a day
		/// </summary>
		/// <param name="time></param>
		/// <returns></returns>
		public List<Test> TestDate(DateTime time)
		{
			var list = from item in TestList()
					   where item.SetUpDate.Date == time.Date
					   select item;
			List<Test> newList = new List<Test>();
			foreach (var s in list)
				newList.Add(s);
			return newList;
		}

		public List<Tester> TesterGrouping()
		{
			List<Tester> TesterGroup = new List<Tester>();
			IEnumerable<IGrouping<VehicleType, Tester>> TesterGroup1 = from item in TesterList()
																	   group item by item.VehicleType;
			foreach (var group in TesterGroup1)
			{
				foreach (var item in group)
				{
					TesterGroup.Add(item);
				}
			}
			return TesterGroup;
		}

		public List<Trainee> TraineeTeacherGrouping()
		{
			List<Trainee> TraineeTeacherGroup = new List<Trainee>();
			IEnumerable<IGrouping<int, Trainee>> TraineeTeacherGroup1 = from item in TraineeList()
																		   group item by item.NumTester;
			foreach (var group in TraineeTeacherGroup1)
			{
				foreach (var item in group)
				{
					TraineeTeacherGroup.Add(item);
				}
			}
			return TraineeTeacherGroup;
		}

		public List<Trainee> TraineeSchoolGrouping()
		{
			List<Trainee> TraineeSchoolGroup = new List<Trainee>();
			IEnumerable<IGrouping<string, Trainee>> TraineeSchoolGroup1 = from item in TraineeList()
																		  group item by item.SchoolName;
			foreach (var group in TraineeSchoolGroup1)
			{
				foreach (var item in group)
				{
					TraineeSchoolGroup.Add(item);
				}
			}
			return TraineeSchoolGroup;
		}

		public List<Trainee> TraineeTestGrouping()
		{
			List<Trainee> TraineeTestGroup = new List<Trainee>();
			IEnumerable<IGrouping<int, Trainee>> TraineeTestGroup1 = from item in TraineeList()
																	 group item by NumTraineeTests(item);
			foreach (var group in TraineeTestGroup1)
			{
				foreach (var item in group)
				{
					TraineeTestGroup.Add(item);
				}
			}
			return TraineeTestGroup;
		}

		public void AddTester(Tester O)
		{
			int num = DateTime.Today.Year - O.Birthday.Year;
			TesterAge(num);
			dal.AddTester(O);
		}

		public void deleteTester(int num)
		{
			dal.deleteTester(num);
		}

		public void UpdateTester(Tester O)
		{
			dal.UpdateTester(O);
		}

		public void AddTrainee(Trainee D)
		{
			int num = DateTime.Today.Year - D.Birthday.Year;
			TraineeAge(num);
			dal.AddTrainee(D);
		}

		public void deleteTrainee(int num)
		{
			dal.deleteTrainee(num);
		}

		public void UpdateTrainee(Trainee D)
		{
			dal.UpdateTrainee(D);
		}

		public void AddTest(Test B)
		{
			SetTest(B);
			Availability(B);
			TestGap(B);
			CheckLessons(B);
			TesterMax(B);
			TestTime(B);
			CheckVehicle(B);
			dal.AddTest(B);
		}

		public void deleteTest(int num)
		{
			dal.deleteTest(num);
		}

		public void UpdateTest(Test B)
		{
			CheckFields(B);
			dal.UpdateTest(B);
		}

		public List<Tester> TesterList()
		{
			return dal.TesterList();
		}

		public List<Trainee> TraineeList()
		{
			return dal.TraineeList();
		}

		public List<Test> TestList()
		{
			return dal.TestList();
		}

		public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)
		{
			return dal.getAllTester(predicat);
		}

		public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
		{
			return dal.getAllTest(predicat);
		}

		public IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null)
		{
			return dal.getAllTrainee(predicat);
		}
	}
}