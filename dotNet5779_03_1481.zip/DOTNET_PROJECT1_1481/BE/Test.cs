﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace BE
{
	public class Test
	{
		public int TestID { get; set; }
		public DistanceParameters DistanceParameters { get; set; }
		public AwarenessParameters AwarenessParameters { get; set; }
		public LightsParameters LightsParameters { get; set; }
		public ParkingParameters ParkingParameters { get; set; }
		public Grade TestGrade { get; set; }
		public string Comments { get; set; }
		public VehicleType TestType { get; set; }
		public int NumTrainee { get; set; }
		public int NumTester { get; set; }
		public string TestAddress { get; set; }
		public DateTime SetUpDate { get; set; }
		public DateTime TestDate { get; set; }

		public override string ToString()//פונקצית הדפסה 
		{
			return "TestID: " + TestID + "\nVehicleType" + TestType + "\nTraineeID" + NumTrainee + "\nTesterID" + NumTester + "\nTestDate" + SetUpDate + "\nTestAddress" + TestAddress + "\nVehicleType" + "\nDistanceParameters : " + DistanceParameters + "\nAwarenessParameters : " + AwarenessParameters + "\nLightsParameters : " + LightsParameters + "\nParkingParameters : " + ParkingParameters + "\nTestGrade: " + TestGrade + "\ncomments: " + Comments;
		}
	}
}