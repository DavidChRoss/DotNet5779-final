﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
	public enum VehicleType { privateVehicle, twoWheelVehicle, mediumTruck, heavyTruck };
	public enum TransmissionType { manual, automatic };
	public enum Gender { man, female, other };
	public enum Grade { pass, fail };
	public enum DistanceParameters { distance_keeping_pass, distance_keeping_fail };
	public enum ParkingParameters { reverse_parking_pass, reverse_parking_fail };
	public enum AwarenessParameters { window_awareness_pass, window_awareness_fail };
	public enum LightsParameters { lights_pass, lights_fail };
}
