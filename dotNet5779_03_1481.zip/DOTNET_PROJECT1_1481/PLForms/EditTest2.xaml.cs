﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLForms
{
    /// <summary>
    /// Interaction logic for EditTest2.xaml
    /// </summary>
    public partial class EditTest2 : Window
    {
		BE.Test test;
		BL.IBL bl;
		public EditTest2()
        {
            InitializeComponent();
			test = new BE.Test();
			bl = BL.FactoryBL.getBL();
			this.TestGrid.DataContext = test;
			GradeComboBox.ItemsSource = Enum.GetValues(typeof(BE.Grade));
			AwarenessComboBox.ItemsSource = Enum.GetValues(typeof(BE.AwarenessParameters));
			ParkingComboBox.ItemsSource = Enum.GetValues(typeof(BE.ParkingParameters));
			LightsComboBox.ItemsSource = Enum.GetValues(typeof(BE.LightsParameters));
			DistanceComboBox.ItemsSource = Enum.GetValues(typeof(BE.DistanceParameters));
			TestIDComboBox.ItemsSource = from item in bl.getAllTest()
											   select item.TestID;
		}
		private void Update_Click(object sender, RoutedEventArgs e)
		{

			try
			{
				bl.UpdateTest(test);
				MessageBox.Show("the test " + test.TestID + " updated  ", " Successfully updated! ");
				test = new BE.Test();
				this.DataContext = test;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void Delete_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				BE.Test br = new BE.Test();
				br = bl.getAllTest().FirstOrDefault(b => b.TestID == test.TestID);
				if (br == null)
					throw new Exception("the test dosn't exist");
				else bl.deleteTrainee(br.TestID);
				MessageBox.Show("the test \"" + test.TestID + "\" Deleted from the system", "Deleted successfully!");
				this.DataContext = test;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
