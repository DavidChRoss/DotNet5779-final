﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for EditTest.xaml
	/// </summary>
	public partial class EditTest1 : Window
	{
		BE.Test test;
		BL.IBL bl;
		public EditTest1()
		{
			InitializeComponent();
			test = new Test();
			this.DataContext = test;
			bl = BL.FactoryBL.getBL();
			VehicleTypeComboBox.ItemsSource = Enum.GetValues(typeof(BE.VehicleType));

		}

		private void Add_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				bl.AddTest(test);
				MessageBox.Show("the test " + test.TestID + " added  ", " Successfully updated! ");
				test = new BE.Test();
				this.DataContext = test;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void Delete_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				BE.Test br = new BE.Test();
				br = bl.getAllTest().FirstOrDefault(b => b.NumTester == test.NumTester && b.NumTrainee == test.NumTrainee && b.SetUpDate == test.SetUpDate);
				if (br == null)
					throw new Exception("the test dosn't exist");
				else bl.deleteTrainee(br.TestID);
				MessageBox.Show("the test \"" + test.TestID + "\" Deleted from the system", "Deleted successfully!");
				this.DataContext = test;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
	

