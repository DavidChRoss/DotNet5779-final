﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;
using DS;

namespace DAL
{
	public class Dal_imp : Idal
	{
		#region Tester
		/// <summary>
		///  check if the Tester already exists
		/// </summary>
		/// <param name="O"></param>
		/// <returns>bool</returns>
		public bool findTester(Tester O)
		{
			foreach (Tester item in DataSource.TesterList)
				if (O.NumTester == item.NumTester)
					return true;
			return false;
		}
		/// <summary>
		/// add a new Tester 
		/// </summary>
		/// <param name="O"></param>
		public void AddTester(Tester O)
		{
			if (!findTester(O))
				DataSource.TesterList.Add(O);
			else
				throw new Exception("the Tester is already exsits");
		}
		/// <summary>
		/// delete from the data base
		/// </summary>
		/// <param name="num"></param>
		public void deleteTester(int num)
		{
			if(DataSource.TesterList.Find(s => s.NumTester == num) == null)
				throw new Exception("this Tester is not exist");
			for (int i = 0; i < DataSource.TesterList.Count; i++)
			{
				if (num == DataSource.TesterList[i].NumTester)
				{
					DataSource.TesterList.RemoveAt(i);
					DataSource.TestList.RemoveAll(T => num == T.NumTester);
				}
			}
		}
		/// <summary>
		/// update from the database
		/// </summary>
		/// <param name="O"></param>
		public void UpdateTester(Tester O)
		{
			if (DataSource.TesterList.Find(s => s.NumTester == O.NumTester) == null)
				throw new Exception("this Tester is not exist");
			for (int i = 0; i < DataSource.TesterList.Count; i++)
				if (DataSource.TesterList[i].NumTester == O.NumTester)
					DataSource.TesterList[i] = O;
		}
		public IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null)
		{
			if (predicat == null)
				return DataSource.TesterList.AsEnumerable();
			return DataSource.TesterList.Where(predicat);
		}

		#endregion
		#region Trainee
		/// <summary>
		/// check if the Trainee already exists
		/// </summary>
		/// <param name="b"></param>
		public bool findTrainee(Trainee D)
		{
			if (DataSource.TraineeList.Count == 0)
				return false;
			foreach (Trainee item in DataSource.TraineeList)
				if (D.NumTrainee == item.NumTrainee)
					return true;
			return false;
		}
		public void AddTrainee(Trainee D)
		{
			if (!findTrainee(D))
				DataSource.TraineeList.Add(D);
			else
				throw new Exception("this Trainee already exists");
		}
		public void deleteTrainee(int num) //recieve Trainee number
		{
			if(DataSource.TraineeList.Find(s => s.NumTester == num) == null)		
				throw new Exception("this Trainee is not exist");
			for (int i = 0; i < DataSource.TraineeList.Count; i++)
			{
				if (num == DataSource.TraineeList[i].NumTester)
				{
					DataSource.TraineeList.RemoveAt(i);
					DataSource.TestList.RemoveAll(T => num == T.NumTrainee);
				}
			}
		}
		public void UpdateTrainee(Trainee D)
		{
			if (DataSource.TesterList.Find(s => s.NumTester == D.NumTrainee) == null)
				throw new Exception("this Trainee does not exist");
			for (int i = 0; i < DataSource.TraineeList.Count; i++)
				if (DataSource.TraineeList[i].NumTrainee == D.NumTrainee)
					DataSource.TraineeList[i] = D;
		}
		public IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null)
		{
			if (predicat == null)
				return DataSource.TraineeList.AsEnumerable();
			return DataSource.TraineeList.Where(predicat);
		}


		#endregion
		#region Test
		/// <summary>
		/// check if the Test already exists
		/// </summary>
		/// <param name="B"></param>
		/// <returns></returns>
		public bool findTest(Test B)
		{
			if (DataSource.TestList.Count == 0)
				return false;
			foreach (Test item in DataSource.TestList)
				if (B.TestID == item.TestID)
					return true;
			return false;
		}
		public void AddTest(Test B)
		{
			///B.Comments = "none";
			///B.TestID = Configuration.testNumber++;
			if (!findTest(B))
				DataSource.TestList.Add(B);
			else
				throw new Exception("this Test already exists");
		}
		public void deleteTest(int num)
		{
			if (DataSource.TestList.Find(s => s.TestID == num) == null)
				throw new Exception("this Test does not exist");
			DataSource.TestList.RemoveAll(d => d.TestID == num);
		}
		public void UpdateTest(Test B)
		{
			if (DataSource.TestList.Find(s => s.TestID == B.TestID) == null)
				throw new Exception("this Test does not exist");
			for (int i = 0; i < DataSource.TestList.Count; i++)
				if (DataSource.TestList[i].TestID == B.TestID)
					DataSource.TestList[i] = B;
		}
		public IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null)
		{
			if (predicat == null)
				return DataSource.TestList.AsEnumerable();
			return DataSource.TestList.Where(predicat);
		}


		#endregion

		public List<Test> TestList()
		{
			return DataSource.TestList;
		}
		public List<Tester> TesterList()
		{
			return DataSource.TesterList;
		}
		public List<Trainee> TraineeList()
		{
			return DataSource.TraineeList;
		}
	}
}
