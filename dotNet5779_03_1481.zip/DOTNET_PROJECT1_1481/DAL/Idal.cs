﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DAL
{
	public interface Idal
	{
		void AddTester(Tester O);
		void deleteTester(int num);
		void UpdateTester(Tester O);
		bool findTester(Tester O);
		IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null);

		void AddTrainee(Trainee D);
		void deleteTrainee(int num);
		void UpdateTrainee(Trainee D);
		bool findTrainee(Trainee D);
		IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null);

		void AddTest(Test B);
		void deleteTest(int num);
		void UpdateTest(Test B);
		bool findTest(Test B);
		IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null);

		List<Tester> TesterList();
		List<Trainee> TraineeList();
		List<Test> TestList();
	}
}
