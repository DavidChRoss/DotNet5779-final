﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DS
{
    public class DataSource
    {
		public static List<Tester> TesterList = new List<Tester>();
		public static List<Trainee> TraineeList = new List<Trainee>();
		public static List<Test> TestList = new List<Test>();
	}
}
