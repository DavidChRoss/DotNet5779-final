﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BE;
using BL;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for EditTester.xaml
	/// </summary>
	public partial class EditTester : Window
	{

		public Dictionary<DayOfWeek, List<bool>> dic;

		BE.Tester tester;
		BL.IBL bl;

		public List<bool> Sun;
		public List<bool> Mon;
		public List<bool> Tues;
		public List<bool> Wed;
		public List<bool> Thurs;
		public EditTester()
		{
		InitializeComponent();
			tester = new BE.Tester();
			bl = BL.FactoryBL.getBL();
			Sun = new List<bool>();
			Mon = new List<bool>();
			Tues = new List<bool>();
			Wed = new List<bool>();
			Thurs = new List<bool>();
			dic = new Dictionary<DayOfWeek, List<bool>>();
			dic.Add(DayOfWeek.Sunday, Sun);
			dic.Add(DayOfWeek.Monday, Mon);
			dic.Add(DayOfWeek.Tuesday, Tues);
			dic.Add(DayOfWeek.Wednesday, Wed);
			dic.Add(DayOfWeek.Thursday, Thurs);
			GenderComboBox.ItemsSource = Enum.GetValues(typeof(BE.Gender));
			VehicleTypeComboBox.ItemsSource = Enum.GetValues(typeof(BE.VehicleType));
			this.TesterProperties.DataContext = tester;


		}
		private void Add_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				tester.WorkTimes = dic;
				bl.AddTester(tester);
				MessageBox.Show("the tester " + tester.PrivateName + " " + tester.FamilyName + " added  ", " Successfully updated! ");
				tester = new BE.Tester();
				this.TesterProperties.DataContext = tester;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

		}
		private void Update_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				tester.WorkTimes = dic;
				bl.UpdateTester(tester);
				MessageBox.Show("the tester " + tester.PrivateName + " " + tester.FamilyName + " added  ", " Successfully updated! ");
				tester = new BE.Tester();
				this.TesterProperties.DataContext = tester;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

		}

		private void Delete_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				BE.Tester br = new BE.Tester();
				br = bl.getAllTester().FirstOrDefault(b => b.NumTester == tester.NumTester);
				if (br == null)
					throw new Exception("the tester dosn't exist");
				else bl.deleteTester(br.NumTester);
				MessageBox.Show("the tester \"" + tester.PrivateName + " " + tester.FamilyName + "\" Deleted from the system", "Deleted successfully!");
				this.TesterProperties.DataContext = tester;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
	    }
		private void CheckBox_Checked1(object sender, RoutedEventArgs e)
		{
			Sun.Add(true);
		}

		private void CheckBox_Unchecked1(object sender, RoutedEventArgs e)
		{
			Sun.Add(false);
		}
		private void CheckBox_Checked2(object sender, RoutedEventArgs e)
		{
			Mon.Add(true);
		}
	
		private void CheckBox_Unchecked2(object sender, RoutedEventArgs e)
		{
			Mon.Add(false);
		}
		private void CheckBox_Checked3(object sender, RoutedEventArgs e)
		{
			Tues.Add(true);
		}

		private void CheckBox_Unchecked3(object sender, RoutedEventArgs e)
		{
			Tues.Add(false);
		}
		private void CheckBox_Checked4(object sender, RoutedEventArgs e)
		{
			Wed.Add(true);
		}

		private void CheckBox_Unchecked4(object sender, RoutedEventArgs e)
		{
			Wed.Add(false);
		}
		private void CheckBox_Checked5(object sender, RoutedEventArgs e)
		{
			Thurs.Add(true);
		}

		private void CheckBox_Unchecked5(object sender, RoutedEventArgs e)
		{
			Thurs.Add(false);
		}
	}
}
