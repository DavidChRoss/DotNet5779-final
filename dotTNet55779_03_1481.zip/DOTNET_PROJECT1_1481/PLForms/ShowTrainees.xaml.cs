﻿using BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLForms
{
	/// <summary>
	/// Interaction logic for ShowTrainees.xaml
	/// </summary>
	public partial class ShowTrainees : Window
	{
		IEnumerable<Trainee> Trainees;
		BL.IBL bl;
		public ShowTrainees()
		{
			InitializeComponent();
			bl = BL.FactoryBL.getBL();
			Trainees = from item in bl.getAllTrainee()
					   select item;
			DataContext = Trainees;
		}
	}
}
