﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace BL
{
	public delegate bool conditionDelegate(Test b);
	public interface IBL
	{
		void TesterAge(int num);
		void TraineeAge(int num);
		void TestGap(Test b);
		void CheckLessons(Test b);
		void Availability(Test b);
		void TesterMax(Test b);
		void CheckFields(Test b);
		void TestTime(Test b);
		void CheckVehicle(Test b);
		void SetTest(Test b);
		List<Tester> TesterArea(string address);
		List<Tester> TesterTime(DateTime time);
		List<Test> Condition_Tests(conditionDelegate condition);
		int NumTraineeTests(Trainee d);
		bool PassedTest(Trainee d);
		List<Test> TestDate(DateTime time);
		List<Tester> TesterGrouping();
		List<Trainee> TraineeTeacherGrouping();
		List<Trainee> TraineeSchoolGrouping();
		List<Trainee> TraineeTestGrouping();


		void AddTester(Tester O);
		void deleteTester(int num);
		void UpdateTester(Tester O);
		IEnumerable<Tester> getAllTester(Func<Tester, bool> predicat = null);

		void AddTrainee(Trainee D);
		void deleteTrainee(int num);
		void UpdateTrainee(Trainee D);
		IEnumerable<Trainee> getAllTrainee(Func<Trainee, bool> predicat = null);

		void AddTest(Test B);
		void deleteTest(int num);
		void UpdateTest(Test B);
		IEnumerable<Test> getAllTest(Func<Test, bool> predicat = null);

		List<Tester> TesterList();
		List<Trainee> TraineeList();
		List<Test> TestList();
	}
}
